package com.example.myapplication

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner

class MainActivity : AppCompatActivity() {

    private lateinit var spinner: Spinner
    private lateinit var calculateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.credit_type_spinner)
        calculateButton = findViewById(R.id.calculate_button)

        val creditTypes = arrayOf("Ипотека", "Автокредит", "Потребительский кредит")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, creditTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        calculateButton.setOnClickListener {
            val selectedCreditType = spinner.selectedItem.toString()
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("credit_type", selectedCreditType)
            startActivity(intent)
        }
    }
}