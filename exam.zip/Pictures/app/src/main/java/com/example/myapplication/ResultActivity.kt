package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


    class ResultActivity : AppCompatActivity() {
        private lateinit var loanAmountEditText: EditText
        private lateinit var interestRateEditText: EditText
        private lateinit var loanTermEditText: EditText

        private lateinit var calculateButton: Button
        private lateinit var resultTextView: TextView

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_result)

            loanAmountEditText = findViewById(R.id.loan_amount_edit_text)
            interestRateEditText = findViewById(R.id.interest_rate_edit_text)
            loanTermEditText = findViewById(R.id.loan_term_edit_text)

            calculateButton = findViewById(R.id.calculate_button)
            resultTextView = findViewById(R.id.result_text_view)

            calculateButton.setOnClickListener {
                val loanAmount = loanAmountEditText.text.toString().toDoubleOrNull() ?: 0.0
                val interestRate = interestRateEditText.text.toString().toDoubleOrNull() ?: 0.0
                val loanTerm = loanTermEditText.text.toString().toIntOrNull() ?: 0
                val creditType = intent.getStringExtra("credit_type")


                val result = calculateMonthlyPayment(loanAmount, interestRate, loanTerm)
                val creditTypeTextView = findViewById<TextView>(R.id.credit_type_text_view)
                creditTypeTextView.text = "Выбранный вид кредита: $creditType"
                val roundedResult = "%.2f".format(result) // Округляем результат до двух десятичных знаков
                resultTextView.text = "Ежемесячный платеж: $roundedResult"
            }
        }

        private fun calculateMonthlyPayment(loanAmount: Double, interestRate: Double, loanTerm: Int): Double {
            // Здесь производится расчет ежемесячного платежа по кредиту
            // Формула для расчета ежемесячного платежежежа по кредиту:
            // M = P * (r * (1 + r)^n) / ((1 + r)^n - 1)
            // где:
            // M - ежемесячный платеж
            // P - сумма кредита
            // r - месячная процентная ставка (годовая ставка / 12 /   100)
            // n - общее количество платежей (срок кредита в месяцах)

            val monthlyInterestRate = interestRate / 12.0 / 100.0
            val totalPayments = loanTerm * 1.0
            val denominator = Math.pow((1 + monthlyInterestRate), totalPayments) - 1
            return loanAmount * monthlyInterestRate * Math.pow((1 + monthlyInterestRate), totalPayments) / denominator
        }
    }